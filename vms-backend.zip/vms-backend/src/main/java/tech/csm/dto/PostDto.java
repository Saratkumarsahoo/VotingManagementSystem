package tech.csm.dto;

public class PostDto {
}
